# Attendance System Full Project
Instructions to setup project on GitHub + Vercel + Supabase.